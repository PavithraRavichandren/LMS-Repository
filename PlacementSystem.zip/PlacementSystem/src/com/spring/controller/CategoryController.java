package com.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.dao.CategoryDAO;
import com.spring.dao.RoleDAO;
import com.spring.domain.Category;
import com.spring.domain.Role;

@Controller
public class CategoryController {
	
	@Autowired
	private CategoryDAO categoryDAO;
	
	@RequestMapping("/createCategory")
	public String createCategory() {
		return "category";
	}
	@RequestMapping("/saveCategory")
	public String saveRole(@RequestParam("category")String name,@RequestParam("description")String description) {
		Category categoryIns = new Category(name,description);
		categoryDAO.saveCategory(categoryIns);
		return "category";
		
	}
	
}
