package com.spring.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.spring.dao.FacultyDAO;
import com.spring.dao.QuestionDAO;
import com.spring.domain.Faculty;
import com.spring.domain.Question;
import com.spring.domain.User;

@SessionAttributes({ "user" })
@Controller
public class FacultyController {
	HttpSession session;
	@Autowired
	private FacultyDAO facultyDAO;
	@Autowired
	private QuestionDAO questionDAO;
	@RequestMapping("/faculty")
	public String faculty() {
		return "faculty";
	}
	@RequestMapping("/saveFaculty") 
	private ModelAndView saveFaculty(Integer experience,HttpServletRequest request) {
		session = request.getSession(false);
		if (session == null) {
		       session = request.getSession();
		   }
		Faculty facultyIns = (Faculty) session.getAttribute("user");
		facultyIns.setExperience(experience);
		facultyDAO.saveExperience(facultyIns);
		List<Question> questionList = (List<Question>)questionDAO.listAllQuestions();
		return new ModelAndView("facultyHome","questionList",questionList);
	}
	
	@RequestMapping("/rejectAnswer")
	public ModelAndView rejectAnswer(@RequestParam("questionId")Integer questionId,HttpServletRequest request) {
		session = request.getSession(true);
		Faculty facultyIns = (Faculty) session.getAttribute("user");
		Question questionIns = questionDAO.getQuestionById(questionId);
		questionIns.setStatus("Rejected");
		questionIns.setFaculty(facultyIns);
		questionDAO.saveAnswer(questionIns);
		return new ModelAndView("redirect:facultyHome.do");
		
	}
	
	@RequestMapping("/getAllQuestions") 
	public ModelAndView getAllQuestions() {
		List<Question> questionList = (List<Question>)questionDAO.listAllQuestions();
		return new ModelAndView("facultyHome","questionList",questionList);
	}
	
	@RequestMapping("/getApprovedAnswers")
	public ModelAndView getApprovedAnswers(HttpServletRequest request,Model model) {
		session = request.getSession(true);
		Faculty facultyIns = (Faculty) session.getAttribute("user");
		System.out.println(facultyIns.getFirstName());
		List<Question> questionList = (List<Question>) questionDAO.getApprovedAnswers(facultyIns);
		model.addAttribute("status", "Approved");
		return new ModelAndView("myApproval","questionList",questionList);
	}
	
	@RequestMapping("/getRejectedAnswers")
	public ModelAndView getRejectedAnswers(HttpServletRequest request,Model model) {
		session = request.getSession(true);
		Faculty facultyIns = (Faculty) session.getAttribute("user");
		System.out.println(facultyIns.getFirstName());
		List<Question> questionList = (List<Question>) questionDAO.getRejectedAnswers(facultyIns);
		model.addAttribute("status", "Rejected");
		return new ModelAndView("myApproval","questionList",questionList);
	}
	
	@RequestMapping("/facultyHome")
	public ModelAndView facultyHome() {
		List<Question> questionList = (List<Question>)questionDAO.listAllQuestions();
		return new ModelAndView("facultyHome","questionList",questionList);
	}

}
