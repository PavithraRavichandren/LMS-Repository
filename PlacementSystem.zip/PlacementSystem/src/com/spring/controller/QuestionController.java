package com.spring.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.spring.dao.CategoryDAO;
import com.spring.dao.QuestionDAO;
import com.spring.domain.Category;
import com.spring.domain.Faculty;
import com.spring.domain.Junior;
import com.spring.domain.Question;
import com.spring.domain.Senior;
import com.spring.domain.User;

@Controller
public class QuestionController {
	HttpSession session;
	@Autowired
	private QuestionDAO questionDAO;
	@Autowired
	private CategoryDAO categoryDAO;
	
	@RequestMapping("/saveQuestion")
	public ModelAndView saveQuestion(@RequestParam("categoryId")Integer categoryId,@RequestParam("question")String question,
			HttpServletRequest request,Model model) {
		session = request.getSession(true);
		User userIns = (User) session.getAttribute("user");
		System.out.print(userIns.getRole().getName());
		Junior juniorIns = (Junior) session.getAttribute("user");
		Question questionIns = new Question();
		Category categoryIns = categoryDAO.getCategoryById(categoryId);
		questionIns.setQueries(question);
		questionIns.setCategory(categoryIns);
		questionIns.setJunior(juniorIns);
		questionDAO.saveQuestion(questionIns);
		List<Question> questionList = (List<Question>)questionDAO.listAllQuestions();
		List<Category> categoryList = categoryDAO.listAllCategory();
		model.addAttribute("categoryList", categoryList);
		return new ModelAndView("redirect:juniorHome.do","questionList",questionList);
	}
	
	
	
	@RequestMapping("/approveAnswer")			
	public String approveAnswer(@RequestParam("questionId")Integer questionId,HttpServletRequest request) {
		session = request.getSession(true);
		Faculty facultyIns = (Faculty) session.getAttribute("user");
		Question questionIns = questionDAO.getQuestionById(questionId);
		questionIns.setStatus("Approved");
		questionIns.setFaculty(facultyIns);
		questionDAO.saveAnswer(questionIns);
		
		return "redirect:getAllQuestions.do";
	}
	
	
	
	
	
	
}
