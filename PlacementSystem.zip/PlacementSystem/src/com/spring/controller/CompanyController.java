package com.spring.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.dao.CompanyDAO;
import com.spring.dao.SeniorDAO;
import com.spring.domain.Company;
import com.spring.domain.Faculty;
import com.spring.domain.Senior;

@Controller
public class CompanyController {
	HttpSession session = null;
	@Autowired
	private SeniorDAO seniorDAO;
	@Autowired
	private CompanyDAO companyDAO;
	@RequestMapping("/saveCompany")
	public String saveCompany(@RequestParam("companyName")String name,@RequestParam("description")String description,
			@RequestParam("createdBy")String createdBy,HttpServletRequest request) {
		Senior seniorIns = (Senior) session.getAttribute("user");
		Company companyIns = new Company(name,description,createdBy);
		seniorIns.setCompany(companyIns);
		seniorDAO.saveSeniorDetails(seniorIns);
		return "seniorHome";
	}
	
	@RequestMapping("/companyCreate") 
	public String companyCreate() {
		return "company";
		
	}
	@RequestMapping("/createCompany") 
	public String createCompany(@RequestParam("companyName")String name,@RequestParam("description")String description,
			@RequestParam("createdBy")String createdBy,HttpServletRequest request) {
		System.out.println("success");
		Company companyIns = new Company(name,description,createdBy);
		companyDAO.saveCompany(companyIns);
		return "company";
		
	}
}
