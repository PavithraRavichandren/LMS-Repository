package com.spring.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.spring.dao.AddressDAO;
import com.spring.dao.UserDAO;
import com.spring.domain.Address;
import com.spring.domain.User;

@SessionAttributes({ "user" })
@Controller
public class AddressController {
	HttpSession session;
	@Autowired
	private AddressDAO addressDAO;
	@Autowired
	private UserDAO userDAO;
	
	@RequestMapping("/saveAddress") 
	public String saveAddress(@RequestParam("streetName")String streetName,@RequestParam("city")String city,
			@RequestParam("state")String state,@RequestParam("country")String country,HttpServletRequest request) {
		Address addressIns = new Address(streetName,city,state,country);
		addressDAO.saveAddress(addressIns);
		session = request.getSession(false);
		if (session == null) {
		       session = request.getSession();
		   }
		User userIns = (User) session.getAttribute("user");
		userDAO.saveUserAddress(userIns,addressIns);
		System.out.println(userIns.getRole().getName());
		if(userIns.getRole().getName().equals("Senior")) {
			return "senior";
		} else if(userIns.getRole().getName().equals("Faculty")) {
			return "faculty";
		} else {
			return "home";
		}		
	}
}

