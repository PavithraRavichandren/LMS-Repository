package com.spring.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.spring.dao.FacultyDAO;
import com.spring.dao.JuniorDAO;
import com.spring.dao.QuestionDAO;
import com.spring.dao.SeniorDAO;
import com.spring.domain.Company;
import com.spring.domain.Faculty;
import com.spring.domain.Junior;
import com.spring.domain.Question;
import com.spring.domain.Senior;
import com.spring.domain.User;

@Controller
public class SeniorController {
	@Autowired
	private SeniorDAO seniorDAO;
	@Autowired
	private JuniorDAO juniorDAO;
	@Autowired
	private QuestionDAO questionDAO;
	private HttpSession session;

	@RequestMapping("/senior")
	public String senior() {
		return "senior";
	}

	@RequestMapping("/editSenior")
	public String editSenior() {
		return "editSenior";
	}

	@RequestMapping("/saveSenior")
	private String saveSenior(@RequestParam("designation") String designation,
			@RequestParam("yearOfPassing") Integer yearOfPassing, @RequestParam("department") String department,
			@RequestParam("companyName") String name, @RequestParam("description") String description,
			@RequestParam("createdBy") String createdBy, HttpServletRequest request) {
		session = request.getSession(false);
		Senior seniorIns = (Senior) session.getAttribute("user");
		seniorIns.setDesignation(designation);
		seniorIns.setYearOfPassing(yearOfPassing);
		seniorIns.setDepartment(department);
		Company companyIns = new Company(name, description, createdBy);
		seniorIns.setCompany(companyIns);
		seniorDAO.saveSeniorDetails(seniorIns);
		System.out.println("Inside Faculty Ctrler");
		return "seniorHome";
	}

	@RequestMapping("/unansweredQuestions")
	public ModelAndView unansweredQuestions() {
		List<Question> questionList = (List<Question>) questionDAO.listUnansweredQuestions();
		return new ModelAndView("seniorHome", "questionList", questionList);
	}

	@RequestMapping("/listMyQA")
	public ModelAndView listMyQA(HttpServletRequest request) {
		session = request.getSession(true);
		Senior seniorIns = (Senior) session.getAttribute("user");
		List<Question> questionList = questionDAO.listMyQA(seniorIns);
		return new ModelAndView("seniorHome", "questionList", questionList);
	}

	@RequestMapping("answeredQuestions")
	public ModelAndView answeredQuestions() {
		List<Question> questionList = (List<Question>) questionDAO.listAllAnsweredApprovedQuestions();
		return new ModelAndView("seniorHome", "questionList", questionList);
	}

	@RequestMapping("/saveAnswer")
	public ModelAndView saveAnswer(@RequestParam("questionId") Integer questionId,
			@RequestParam("answer") String answer, HttpServletRequest request) {
		session = request.getSession();
		Senior seniorIns = (Senior) session.getAttribute("user");
		User userIns = (User) session.getAttribute("user");
		Question questionIns = questionDAO.getQuestionById(questionId);
		questionIns.setAnswer(answer);
		questionIns.setSenior(seniorIns);
		questionIns.setStatus("Answered");
		questionDAO.saveAnswer(questionIns);
		List<Question> questionList = (List<Question>) questionDAO.listMyQuestions(userIns);
		questionList.addAll(questionDAO.listUnansweredQuestions());
		return new ModelAndView("seniorHome", "questionList", questionList);
	}
	
	@RequestMapping("/convertToSenior")
	public String convertToSenior(@RequestParam("juniorId")Integer juniorId) {
		User userIns = (User) juniorDAO.getJuniorById(juniorId);
		return "redirect:senior.do";
		
	}
	@RequestMapping("/seniorHome")
	public ModelAndView seniorHome() {
		List<Question> questionList = (List<Question>)questionDAO.listAllAnsweredApprovedQuestions();
		return new ModelAndView("seniorHome","questionList",questionList);
	}
}
