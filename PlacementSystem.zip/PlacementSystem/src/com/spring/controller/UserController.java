package com.spring.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.icu.text.SimpleDateFormat;
import com.spring.dao.CategoryDAO;
import com.spring.dao.FacultyDAO;
import com.spring.dao.QuestionDAO;
import com.spring.dao.RoleDAO;
import com.spring.dao.SeniorDAO;
import com.spring.dao.UserDAO;
import com.spring.domain.Address;
import com.spring.domain.Category;
import com.spring.domain.Faculty;
import com.spring.domain.Junior;
import com.spring.domain.Question;
import com.spring.domain.Role;
import com.spring.domain.Senior;
import com.spring.domain.User;

@SessionAttributes({ "user" })
@Controller
public class UserController {

	HttpSession session;
	@Autowired
	private RoleDAO roleDAO;
	@Autowired
	private UserDAO userDAO;
	@Autowired
	private FacultyDAO facultyDAO;
	@Autowired
	private SeniorDAO seniorDAO;
	@Autowired
	private CategoryDAO categoryDAO;
	@Autowired
	private QuestionDAO questionDAO;
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	@RequestMapping("/index")
	public String index() {
		return "index";
	}

	@RequestMapping("/signup")
	public ModelAndView signup(@RequestParam("faculty") Integer faculty) {
		if (faculty == 0) {
			return new ModelAndView("signup", "", "");
		} else {
			return new ModelAndView("signup", "faculty", faculty);
		}
	}

	@RequestMapping("/saveUser")
	public String saveUser(@RequestParam("firstName") String firstName, @RequestParam("lastName") String lastName,
			@RequestParam("password") String password, @RequestParam("email") String email,
			@RequestParam("mobile") Long mobile, @RequestParam("dateOfBirth") String dateOfBirth,
			@RequestParam("role") String roleName, @RequestParam("gender") String gender, HttpServletRequest request) {
		java.sql.Date dob = null;
		Faculty facultyIns = null;
		Senior seniorIns = null;
		Role roleIns = roleDAO.getRoleByName(roleName);
		try {
			java.util.Date d1 = sdf.parse(dateOfBirth);
			dob = new java.sql.Date(d1.getTime());
		} catch (Exception e) {
			System.out.println(e);
		}
		if(roleIns.getName().equals("Faculty")) {
			facultyIns = new Faculty(firstName, lastName, password, email, mobile, gender, dob, roleIns,1);
			facultyDAO.saveFaculty(facultyIns);
			session = request.getSession(true);
			session.setAttribute("user", facultyIns);
			Faculty f = (Faculty) session.getAttribute("user");
			session.setAttribute("loginStatus", "true");
		} else if(roleIns.getName().equals("Senior")) {
			seniorIns = new Senior(firstName, lastName, password, email, mobile, gender, dob, roleIns);
			seniorDAO.saveSenior(seniorIns);
			session = request.getSession(true);
			session.setAttribute("user", seniorIns);
			session.setAttribute("loginStatus", "true");
		}
		
		return "address";
	}

	@RequestMapping("/login")
	public ModelAndView login(@RequestParam("email") String email, @RequestParam("password") String password,
			HttpServletRequest request,Model model) {
		User userIns = userDAO.login(email, password);
		if (userIns != null) {
			session = request.getSession();
			session.setAttribute("user", userIns);
			session.setAttribute("loginStatus", "true");
			User userIns1 = (User) session.getAttribute("user");
			System.out.println("session-user-role"+userIns1.getRole().getName());
			if(userIns.getRole().getName().equals("Faculty")) {
				List<Question> questionList = (List<Question>)questionDAO.listAllQuestions();
				return new ModelAndView("facultyHome","questionList",questionList);
			} else if(userIns.getRole().getName().equals("Senior")) {
				//List<Question> questionList = (List<Question>)questionDAO.listMyQuestions(userIns);
				//model.addAttribute("questionList", questionList);
				//questionList.addAll(questionDAO.listUnansweredQuestions());
				//List<Question> questionList = (List<Question>)questionDAO.listMyQuestions(userIns);
				return new ModelAndView("redirect:seniorHome.do","","");
			} else {
				List<Category> categoryList = categoryDAO.listAllCategory();
				List<Question> questionList = (List<Question>)questionDAO.listAllAnsweredApprovedQuestions();
				model.addAttribute("questionList", questionList);
				return new ModelAndView("home","categoryList",categoryList);
			}
		} else {
			return new ModelAndView("index", "error", "Email or Password may be incorrect!");
		}

	}
	
	
	
	
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public ModelAndView invalidate(@ModelAttribute User user) {
		session.removeAttribute("user");
		session.invalidate();
		return new ModelAndView("/index");
	}

}
