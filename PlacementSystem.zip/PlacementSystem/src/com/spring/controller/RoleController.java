package com.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.dao.RoleDAO;
import com.spring.domain.Role;

@Controller
public class RoleController {
	@Autowired
	private RoleDAO roleDAO;
	
	@RequestMapping("/createRole")
	public String createRole() {
		return "role";
	}
	@RequestMapping("/saveRole")
	public String saveRole(@RequestParam("role")String role,@RequestParam("description")String description) {
		Role roleIns = new Role(role,description);
		roleDAO.saveRole(roleIns);
		return "role";
		
	}

}
