package com.spring.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ibm.icu.text.SimpleDateFormat;
import com.spring.dao.CategoryDAO;
import com.spring.dao.JuniorDAO;
import com.spring.dao.QuestionDAO;
import com.spring.dao.RoleDAO;
import com.spring.domain.Category;
import com.spring.domain.Junior;
import com.spring.domain.Question;
import com.spring.domain.Role;

@Controller
public class JuniorController {
	private HttpSession session;
	@Autowired
	private JuniorDAO juniorDAO;
	@Autowired
	private CategoryDAO categoryDAO;
	@Autowired
	private QuestionDAO questionDAO;
	@Autowired
	private RoleDAO roleDAO;
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	@RequestMapping("/saveJunior")
	public String saveJunior(@RequestParam("firstName") String firstName, @RequestParam("lastName") String lastName,
			@RequestParam("password") String password, @RequestParam("email") String email,
			@RequestParam("mobile") Long mobile, @RequestParam("dateOfBirth") String dateOfBirth,
			 @RequestParam("gender") String gender, 
			@RequestParam("batch")Integer batch,@RequestParam("department")String department,HttpServletRequest request) {
		java.sql.Date dob = null;
		try {
			java.util.Date d1 = sdf.parse(dateOfBirth);
			dob = new java.sql.Date(d1.getTime());
		} catch (Exception e) {
			System.out.println(e);
		}
		Role roleIns = roleDAO.getRoleByName("Junior");
		Junior juniorIns = new Junior(firstName, lastName, password, email, mobile, gender, dob, roleIns,null,batch,department);
		juniorDAO.saveJunior(juniorIns);
		return "facultyHome";
		
	}
	
	@RequestMapping("/getMyQuestions")
	public ModelAndView getMyQuestions(HttpServletRequest request,Model model) {
		session = request.getSession(true);
		Junior juniorIns = (Junior) session.getAttribute("user");
		System.out.println("askjbajkdfs"+juniorIns.getFirstName());
		List<Question> questionList = (List<Question>) questionDAO.getMyQuestions(juniorIns);
		List<Category> categoryList = categoryDAO.listAllCategory();
		model.addAttribute("categoryList", categoryList);
		return new ModelAndView("home","questionList",questionList);
		
	}
	
	@RequestMapping("/listAnsweredApprovedQuestions")
	public ModelAndView listAnsweredApprovedQuestions(Model model) {
		List<Question> questionList = questionDAO.listAllAnsweredApprovedQuestions();
		List<Category> categoryList = categoryDAO.listAllCategory();
		model.addAttribute("categoryList", categoryList);
		return new ModelAndView("home","questionList",questionList);
		
	}
	
	@RequestMapping("/juniorHome")
	public ModelAndView juniorHome(Model model) {
		List<Category> categoryList = categoryDAO.listAllCategory();
		List<Question> questionList = (List<Question>)questionDAO.listAllAnsweredApprovedQuestions();
		model.addAttribute("questionList", questionList);
		return new ModelAndView("home","categoryList",categoryList);
	}
	
	@RequestMapping("/juniorList")
	public ModelAndView juniorList() {
		List<Junior> juniorList = juniorDAO.getJuniorList();
		return new ModelAndView("convert","juniorList",juniorList);
	}

}
