	package com.spring.domain;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.ForeignKey;
import org.springframework.beans.factory.annotation.Autowired;

//@Entity
//@Table(name="Senior")
@Entity  
@Table(name="Senior")  
@PrimaryKeyJoinColumn(name="ID")  
public class Senior extends User{
	@Column(name="designation")
	private String designation;
	@Column(name="yearOfPassing")
	private Integer yearOfPassing;
	@Column(name="department")
	private String department;
	@OneToOne
	@ForeignKey(name="company")
	@Autowired
	private Company company;
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public Integer getYearOfPassing() {
		return yearOfPassing;
	}
	public void setYearOfPassing(Integer yearOfPassing) {
		this.yearOfPassing = yearOfPassing;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public Company getCompany() {
		return company;
	}
	public void setCompany(Company company) {
		this.company = company;
	}
	public Senior(Integer id, String firstName, String lastName, String password, String email, Long mobileNumber,
			String gender, Integer collegeId, Date dateOfBirth, Role role, Address address, String name,
			String designation, Integer yearOfPassing, String department, Company company) {
		super(id, firstName, lastName, password, email, mobileNumber, gender, collegeId, dateOfBirth, role, address);
		this.designation = designation;
		this.yearOfPassing = yearOfPassing;
		this.department = department;
		this.company = company;
	}
	public Senior(String firstName, String lastName, String password, String email, Long mobileNumber,
			String gender, Date dateOfBirth, Role role, String designation,Integer yearOfPassing,String department,Company company  ) {
		super( firstName, lastName, password, email, mobileNumber, gender, dateOfBirth, role);
		this.designation = designation;
		this.yearOfPassing = yearOfPassing;
		this.department = department;
		this.company = company;
	}
	public Senior() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Senior(Integer id, String firstName, String lastName, String password, String email, Long mobileNumber,
			String gender, Integer collegeId, Date dateOfBirth, Role role, Address address) {
		super(id, firstName, lastName, password, email, mobileNumber, gender, collegeId, dateOfBirth, role, address);
		// TODO Auto-generated constructor stub
	}
	public Senior(String firstName, String lastName, String password, String email, Long mobileNumber, String gender,
			Date dateOfBirth, Role role, Address address) {
		super(firstName, lastName, password, email, mobileNumber, gender, dateOfBirth, role, address);
		// TODO Auto-generated constructor stub
	}
	public Senior(String firstName, String lastName, String password, String email, Long mobileNumber, String gender,
			Date dateOfBirth, Role role) {
		super(firstName, lastName, password, email, mobileNumber, gender, dateOfBirth, role);
		// TODO Auto-generated constructor stub
	}
	

}
