package com.spring.domain;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.ForeignKey;
import org.springframework.beans.factory.annotation.Autowired;

@Entity
@Table(name="Question")
public class Question {
	@Id
	@GeneratedValue
	@Column(name="Id")
	private Integer id;
	@Column(name="queries")
	private String queries;
	@Column(name="answer")
	private String answer;
	@OneToOne
	@ForeignKey(name="posted_by")
	@Autowired
	private Junior junior;
	@OneToOne
	@ForeignKey(name="verified_by")
	@Autowired
	private Faculty faculty;
	@Column(name="postedDate")
	private Date postedDate;
	@Column(name="status")
	private String status;
	@ManyToOne
	@ForeignKey(name="category")
	private Category category;
	@OneToOne
	@ForeignKey(name="senior")
	private Senior senior;
	public Question(Integer id, String queries, String answer, Junior junior, Faculty faculty, Date postedDate,
			String status, Category category, Senior senior) {
		super();
		this.id = id;
		this.queries = queries;
		this.answer = answer;
		this.junior = junior;
		this.faculty = faculty;
		this.postedDate = postedDate;
		this.status = status;
		this.category = category;
		this.senior = senior;
	}
	
	public Question(String queries, String answer, Junior junior, Faculty faculty, Date postedDate, String status,
			Category category, Senior senior) {
		super();
		this.queries = queries;
		this.answer = answer;
		this.junior = junior;
		this.faculty = faculty;
		this.postedDate = postedDate;
		this.status = status;
		this.category = category;
		this.senior = senior;
	}
	

	public Question(String queries, Junior junior, Date postedDate, String status, Category category) {
		super();
		this.queries = queries;
		this.junior = junior;
		this.postedDate = postedDate;
		this.status = status;
		this.category = category;
	}

	public Question() {
		// TODO Auto-generated constructor stub
	}

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getQueries() {
		return queries;
	}
	public void setQueries(String queries) {
		this.queries = queries;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public Junior getJunior() {
		return junior;
	}
	public void setJunior(Junior junior) {
		this.junior = junior;
	}
	public Faculty getFaculty() {
		return faculty;
	}
	public void setFaculty(Faculty faculty) {
		this.faculty = faculty;
	}
	public Date getPostedDate() {
		return postedDate;
	}
	public void setPostedDate(Date postedDate) {
		this.postedDate = postedDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public Senior getSenior() {
		return senior;
	}
	public void setSenior(Senior senior) {
		this.senior = senior;
	}
	

}
