package com.spring.domain;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

//@Entity
//@Table(name="Faculty")
@Entity  
@Table(name="Faculty")  
@PrimaryKeyJoinColumn(name="ID")  
public class Faculty extends User {
	@Column(name="experience")
	private Integer experience;

	public Integer getExperience() {
		return experience;
	}

	public void setExperience(Integer experience) {
		this.experience = experience;
	}

	public Faculty() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Faculty(Integer experience) {
		super();
		this.experience = experience;
		// TODO Auto-generated constructor stub
	}




	public Faculty(Integer id, String firstName, String lastName, String password, String email, Long mobileNumber,
			String gender, Integer collegeId, Date dateOfBirth, Role role, Address address, Integer experience) {
		super(id, firstName, lastName, password, email, mobileNumber, gender, collegeId, dateOfBirth, role, address);
		this.experience = experience;
	}
	public Faculty(String firstName, String lastName, String password, String email, Long mobileNumber,
			String gender, Date dateOfBirth, Role role,  Integer experience) {
		super( firstName, lastName, password, email, mobileNumber, gender, dateOfBirth, role);
		this.experience = experience;
	}

	
	
}
