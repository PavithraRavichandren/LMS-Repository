package com.spring.domain;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.*;  
@Entity  
@Table(name="junior")  
@PrimaryKeyJoinColumn(name="ID")  
//@Entity
//@Table(name="Junior")
public class Junior extends User{
	@Column(name="batch")
	private Integer batch;
	@Column(name="department")
	private String department;
	public Junior( String firstName, String lastName, String password, String email, Long mobileNumber,
			String gender,  Date dateOfBirth, Role role, Address address, Integer batch,
			String department) {
		super( firstName, lastName, password, email, mobileNumber, gender,  dateOfBirth, role, address);
		this.batch = batch;
		this.department = department;
	}
	
	public Integer getBatch() {
		return batch;
	}
	public void setBatch(Integer batch) {
		this.batch = batch;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public Junior() {
		
	}
	

}
