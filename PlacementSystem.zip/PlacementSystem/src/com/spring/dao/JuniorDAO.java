package com.spring.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.domain.Junior;
import com.spring.domain.Question;
import com.spring.domain.Senior;

@Service
public class JuniorDAO {
	Criteria criteria = null;
	@Autowired
	public SessionFactory sessionFactory;

	@Autowired
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Transactional
	public void saveJunior(Junior juniorIns) {
		sessionFactory.getCurrentSession().save(juniorIns);
	}
	
	@SuppressWarnings("unchecked")
	@Transactional
	public List<Junior> getJuniorList() {
		criteria = sessionFactory.getCurrentSession().createCriteria(Junior.class);
		return (List<Junior>) criteria.list();
	}
	
	@SuppressWarnings("unchecked")
	@Transactional
	public Junior getJuniorById(Integer juniorId) {
		criteria = sessionFactory.getCurrentSession().createCriteria(Junior.class);
		criteria.add(Restrictions.eq("id", juniorId));
		return (Junior) criteria.uniqueResult();
	}
	
	
}
