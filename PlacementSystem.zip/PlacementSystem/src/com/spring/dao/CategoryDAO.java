package com.spring.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.spring.domain.Category;

@Service
public class CategoryDAO {
	Criteria criteria = null;
	@Autowired
	public SessionFactory sessionFactory;

	@Autowired
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	@Transactional
	public void saveCategory(Category categoryIns) {
		sessionFactory.getCurrentSession().save(categoryIns);
	}
	@SuppressWarnings("unchecked")
	@Transactional
	public List<Category> listAllCategory() {
		criteria = sessionFactory.getCurrentSession().createCriteria(Category.class);
		return (List<Category>) criteria.list();
	}
	
	@Transactional
	public Category getCategoryById(Integer categoryId) {
		criteria = sessionFactory.getCurrentSession().createCriteria(Category.class);
		criteria.add(Restrictions.eq("id", categoryId));
		return (Category) criteria.uniqueResult();
		
	}

}
