package com.spring.dao;

import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.domain.Faculty;
import com.spring.domain.Junior;
import com.spring.domain.Question;
import com.spring.domain.Senior;
import com.spring.domain.User;

@Service
public class QuestionDAO {
	Criteria criteria = null;
	@Autowired
	public SessionFactory sessionFactory;

	@Autowired
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public void saveQuestion(Question questionIns) {
		questionIns.setPostedDate(new Date());
		questionIns.setStatus("Unanswered");
		sessionFactory.getCurrentSession().save(questionIns);
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public List<Question> listAllQuestions() {
		criteria = sessionFactory.getCurrentSession().createCriteria(Question.class);
		return (List<Question>) criteria.list();
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public List<Question> listMyQuestions(User userIns) {
		criteria = sessionFactory.getCurrentSession().createCriteria(Question.class);
		criteria.add(Restrictions.eq("senior", userIns));
		return (List<Question>) criteria.list();
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public List<Question> listUnansweredQuestions() {
		criteria = sessionFactory.getCurrentSession().createCriteria(Question.class);
		criteria.add(Restrictions.eq("status", "Unanswered"));
		return (List<Question>) criteria.list();
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public List<Question> listAllAnsweredApprovedQuestions() {
		criteria = sessionFactory.getCurrentSession().createCriteria(Question.class);
		criteria.add(Restrictions.or(Restrictions.eq("status", "Answered"), Restrictions.eq("status", "Approved")));
		return (List<Question>) criteria.list();
	}

	@Transactional
	public Question getQuestionById(Integer questionId) {
		criteria = sessionFactory.getCurrentSession().createCriteria(Question.class);
		criteria.add(Restrictions.eq("id", questionId));
		return (Question) criteria.uniqueResult();
	}

	@Transactional
	public void saveAnswer(Question questionIns) {
		sessionFactory.getCurrentSession().update(questionIns);
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public List<Question> getApprovedAnswers(Faculty facultyIns) {
		criteria = sessionFactory.getCurrentSession().createCriteria(Question.class);
		criteria.add(Restrictions.and(Restrictions.eq("faculty", facultyIns), Restrictions.eq("status", "Approved")));
		return (List<Question>) criteria.list();
	}
	
	@SuppressWarnings("unchecked")
	@Transactional
	public List<Question> getRejectedAnswers(Faculty facultyIns) {
		criteria = sessionFactory.getCurrentSession().createCriteria(Question.class);
		criteria.add(Restrictions.and(Restrictions.eq("faculty", facultyIns), Restrictions.eq("status", "Rejected")));
		return (List<Question>) criteria.list();
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public List<Question> getMyQuestions(Junior juniorIns) {
		criteria = sessionFactory.getCurrentSession().createCriteria(Question.class);
		criteria.add(Restrictions.eq("junior", juniorIns));
		return (List<Question>) criteria.list();
	}
	
	
	@SuppressWarnings("unchecked")
	@Transactional
	public List<Question> listMyQA(Senior seniorIns) {
		criteria = sessionFactory.getCurrentSession().createCriteria(Question.class);
		criteria.add(Restrictions.eq("senior", seniorIns));
		return (List<Question>) criteria.list();
	}
}
