package com.spring.dao;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.domain.Address;
import com.spring.domain.User;

@Service
public class UserDAO {
	Criteria criteria = null;
	@Autowired
	public SessionFactory sessionFactory;

	@Autowired
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Transactional
	public void saveUser(User userIns) {
		sessionFactory.getCurrentSession().save(userIns);
	}
	
	@Transactional
	public User login(String email,String password) {
		criteria = sessionFactory.getCurrentSession().createCriteria(User.class);
		criteria.add(Restrictions.eq("email", email));
		criteria.add(Restrictions.eq("password", password));
		 return (User) criteria.uniqueResult();
	}
	
	@Transactional
	public void saveUserAddress(User userIns,Address addressIns) {
		userIns.setAddress(addressIns);
		sessionFactory.getCurrentSession().saveOrUpdate(userIns);
	}

}
