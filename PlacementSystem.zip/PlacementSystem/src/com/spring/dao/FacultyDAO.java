package com.spring.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.domain.Faculty;

@Service
public class FacultyDAO {
	@Autowired
	private SessionFactory sessionFactory;

	@Autowired
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	@Transactional
	public void saveFaculty(Faculty facultyIns) {
		sessionFactory.getCurrentSession().save(facultyIns);
	}
	@Transactional
	public void saveExperience(Faculty facultyIns) {
		sessionFactory.getCurrentSession().update(facultyIns);
	}
}
